from fastapi import FastAPI, HTTPException, Request
from pymongo import MongoClient
from datetime import datetime

app = FastAPI()

# MongoDB connection
client = MongoClient("mongodb://127.0.0.1:27017")
db = client["SystemBot"]

tickets_collection = db["tickets"]             # Existing collection
ticket_views_collection = db["ticket_views"]   # NEW collection (table)

# ---------------- User: View ticket status + log view details ----------------
@app.get("/ticket/status/{ticket_id}")
def ticket_status(ticket_id: str, request: Request):

    # Find ticket in tickets collection
    ticket = tickets_collection.find_one({"ticket_id": ticket_id}, {"_id": 0})

    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    # Create view log (NEW table)
    view_log = {
        "ticket_id": ticket_id,
        "viewed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "viewer_ip": request.client.host,
        "user_agent": request.headers.get("user-agent")
    }

    # Insert into ticket_views collection
    ticket_views_collection.insert_one(view_log)

    # Return ticket details to user
    return ticket

# ---------------- Admin: Get all view logs ----------------
@app.get("/admin/ticket-views")
def get_ticket_views():
    views = list(ticket_views_collection.find({}, {"_id": 0}))
    return views
